# 
# Part 1 (Azure CLI)
# 

# Log in to Azure Portal if not working in the Cloud Shell
az login

# Select a subscription
az account set --subscription "<Subsription Name>"

# Start a container
az container create --resource-group RG-Containers --name aze-hello --image shekeriev/aze-image-1 --dns-name-label aze-hello --ports 80

# Display container information
az container show --resource-group RG-Containers --name aze-hello

# Display just the FQDN and Public IP address of a container
az container show --resource-group RG-Containers --name aze-hello --query "{FQDN:ipAddress.fqdn,IP:ipAddress.ip}" --output table

# Show container's logs
az container logs --resource-group RG-Containers --name aze-hello

# Attach to container's stdout
az container attach --resource-group RG-Containers --name aze-hello

# Execute a command in a container
az container exec --resource-group RG-Containers --name aze-hello --exec-command hostname

# Establisn a session to a container
az container exec --resource-group RG-Containers --name aze-hello --exec-command /bin/sh

# Execute a command in an existing session
ls
hostname
uname -a
exit

# Delete a container
az container delete --resource-group RG-Containers --name aze-hello

# 
# Part 1 (Azure PowerShell)
# 

# Log in to Azure Portal if not working in the Cloud Shell
Connect-AzAccount

# Select a subscription for the session
Set-AzContext -Subscription "<Subscription Name>"

# Create a container
New-AzContainerGroup -ResourceGroupName RG-Containers -Name aze-hello -Image shekeriev/aze-image-1 -DnsNameLabel aze-hello -Port 80

# Inspect a container
Get-AzContainerGroup -ResourceGroupName RG-Containers -Name aze-hello

# Return container's FQDN and Public IP Address
Get-AzContainerGroup -ResourceGroupName RG-Containers -Name aze-hello | Select IpAddress, Fqdn

# Explore container's logs
Get-AzContainerInstanceLog -ResourceGroupName RG-Containers -Name aze-hello -ContainerGroupName aze-hello

# Delete a container
Remove-AzContainerGroup -ResourceGroupName RG-Containers -Name aze-hello

# 
# Part 1 (Docker Image)
# 

# Follow the instructions to change the web application

# Build a Docker image
docker build . -t aze-image-2

# List available images
docker images

# Run the app locally
docker run -d -p 8080:80 aze-image-2

# Tag the image
docker tag aze-image-2 azecr2021.azurecr.io/aze-image-2:v1

# Log in to the registry
az acr login --name azecr2021

# Push the image to the registry
docker push azecr2021.azurecr.io/aze-image-2:v1

# List repositories in an registry
az acr repository list --resource-group RG-Containers --name azecr2021 --output table

# List repositories in an registry (shorter version)
az acr repository list --name azecr2021 --output table

# List repository's tags
az acr repository show-tags --resource-group RG-Containers --name azecr2021 --repository aze-image-2 --output table

# List repository's tags (shorter version)
az acr repository show-tags --name azecr2021 --repository aze-image-2 --output table

# Create a container based on the newly created image
az container create --resource-group RG-Containers --name aze-hello --image azecr2021.azurecr.io/aze-image-2:v1 --cpu 1 --memory 1 --registry-login-server azecr2021.azurecr.io --registry-username azecr2021 --registry-password "Rj+92PBqfat2d9mbHhGQCHpJK2PN79d7" --dns-name-label aze-hello --ports 80

# 
# Part 2 (Azure CLI)
# 

# Log in to Azure Portal if not working in the Cloud Shell
az login

# Select a subscription
az account set --subscription "<Subscription Name>"

# Create new resource group
az group create --name RG-WebApps-Win --location westeurope

# Create web (HTML) application and service plan (Windows)
az webapp up --resource-group RG-WebApps-Win --location westeurope --name azewebapp1 --html --plan Windows-WebApp-Plan --sku F1

# List web applications
az webapp list --resource-group RG-WebApps-Win

# List only the application name and URL
az webapp list --resource-group RG-WebApps-Win --query "[].{Name:name,URL:defaultHostName}" --output table

# Redeploy the web application
az webapp up --resource-group RG-WebApps-Win --location westeurope --name azewebapp1 --html