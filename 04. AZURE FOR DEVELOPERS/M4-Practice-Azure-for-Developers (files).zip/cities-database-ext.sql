CREATE TABLE Cities (CityCode char(4), CityName nvarchar(50), Population int);

INSERT INTO Cities VALUES ('BG22', 'Sofia', 1307376);
INSERT INTO Cities VALUES ('BG16', 'Plovdiv', 341625);
INSERT INTO Cities VALUES ('BG03', 'Varna', 334466);
INSERT INTO Cities VALUES ('BG02', 'Burgas', 203017);
INSERT INTO Cities VALUES ('BG24', 'Stara Zagora', 148443);
INSERT INTO Cities VALUES ('BG18', 'Ruse', 145765);
INSERT INTO Cities VALUES ('BG15', 'Pleven', 99628);
INSERT INTO Cities VALUES ('BG20', 'Sliven', 87895);
INSERT INTO Cities VALUES ('BG08', 'Dobrich', 86292);
INSERT INTO Cities VALUES ('BG04', 'Veliko Tarnovo', 73508);
