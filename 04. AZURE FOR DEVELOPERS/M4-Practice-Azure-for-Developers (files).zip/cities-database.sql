CREATE TABLE Cities (CityName nvarchar(50), Population int);

INSERT INTO Cities VALUES ('Sofia', 1307376);
INSERT INTO Cities VALUES ('Plovdiv', 341625);
INSERT INTO Cities VALUES ('Varna', 334466);
INSERT INTO Cities VALUES ('Burgas', 203017);
INSERT INTO Cities VALUES ('Stara Zagora', 148443);
INSERT INTO Cities VALUES ('Ruse', 145765);
INSERT INTO Cities VALUES ('Pleven', 99628);
INSERT INTO Cities VALUES ('Sliven', 87895);
INSERT INTO Cities VALUES ('Dobrich', 86292);
INSERT INTO Cities VALUES ('Veliko Tarnovo', 73508);
