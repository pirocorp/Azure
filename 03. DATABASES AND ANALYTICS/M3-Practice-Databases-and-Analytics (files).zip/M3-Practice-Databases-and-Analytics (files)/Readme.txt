Package contents:
-----------------
 1) AzureBlobJsonGenerator-bin.zip -> Compiled application used to generate sensor-like data
 2) AzureBlobJsonGenerator-src.zip -> Visual Studio 2019 solution for the application
 3) BGCities.bacpac                -> SQL Server database export, used to demonstrate database import functionality in Azure
 4) Cosmos-DB-Sample-Data.txt      ->  Sample data used during the Cosmos DB demonstration

* Do not forget to modify the settings in the App.config (for the solution) or AzureBlobJsonGenerator.exe.config (for the compiled app) file to match your situation