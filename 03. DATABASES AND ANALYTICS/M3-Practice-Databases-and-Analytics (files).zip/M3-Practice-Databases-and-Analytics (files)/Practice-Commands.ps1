# 
# Part 1: Azure SQL (Azure CLI)
# 

# Login to Azure
az login

# List subscriptions if more than one
az account list --output table

# Set a default subscription for the session
az account set --subscription "MSDN Platforms Subscription"

# Set default vaules (permanent but changeable)
az configure --defaults group=RG-SQL sql-server=dvzsql

# Get help
az sql db --help

# List databses
az sql db list

az sql db list --query [].name

az sql db list --output table

# Create a database
az sql db create --name DBCLI --edition Basic --capacity 5

# 
# Part 1: Azure SQL (PowerShell)
# 

# Login to Azure
Connect-AzAccount

# List available subscriptions if more than one
Get-AzSubscription

# Select a subscription for the session
Set-AzContext -Subscription "MSDN Platforms Subscription"

# List commands related to Azure SQL Server
Get-Command *azsqlserver*

# List commands related to Azure SQL Database
Get-Command *azsqldatabase*

# List available databases
Get-AzSqlDatabase -ServerName dvzsql -ResourceGroupName RG-SQL

Get-AzSqlDatabase -ServerName dvzsql -ResourceGroupName RG-SQL | FT

Get-AzSqlDatabase -ServerName dvzsql -ResourceGroupName RG-SQL | Select -Property DatabaseName

# Create a database
New-AzSqlDatabase -DatabaseName DBPS -ResourceGroupName RG-SQL -ServerName dvzsql -Edition Basic

# 
# Part 1: Azure SQL (Azure CLI + SQLCMD)
# 

# Get a connection string
az sql db show-connection-string --client sqlcmd --name BGCities

# Connect to a database
sqlcmd -S tcp:dvzsql.database.windows.net,1433 -d BGCities -U demosa -P "DemoPassword-2021" -N -l 30

# Execute a statement to show a database version
SELECT @@version;
GO

# Execute a statement to change the active database
USE BGCities;
GO

# Execute a statement to select all columns and all records from a table
SELECT * FROM TopCities;
GO

# Close the session to the database
QUIT

# 
# Part 2: Azure CosmosDB (Azure CLI)
# 

# Login to Azure
az login

# Get help for a command
az cosmosdb sql --help

# List databases
az cosmosdb sql database list --account-name dvzcos --resource-group RG-CosmosDB

az cosmosdb sql database list --account-name dvzcos --resource-group RG-CosmosDB --query [].name

# Create a database
az cosmosdb sql database create --account-name dvzcos --resource-group RG-CosmosDB --name AZDB

# Create a collection
az cosmosdb sql container create --account-name dvzcos --resource-group RG-CosmosDB --database-name AZDB --name People --partition-key-path /city --throughput 400

#
# Part 2: Azure CosmosDB (PowerShell)
# 

# Login to Azure
Connect-AzAccount

# Select a subscription if more than one
Set-AzContext -Subscription "MSDN Platforms Subscription"

# Work without the specialized module Az.CosmosDB

Get-AzResource -ResourceType Microsoft.DocumentDB/databaseAccounts/apis/databases `
-ApiVersion "2015-04-08" -ResourceGroupName "RG-CosmosDB" -Name "dvzcos/sql/"

Get-AzResource -ResourceType Microsoft.DocumentDB/databaseAccounts/apis/databases `
-ApiVersion "2015-04-08" -ResourceGroupName "RG-CosmosDB" -Name "dvzcos/sql/TimeTracker"

Get-AzResource -ResourceType Microsoft.DocumentDB/databaseAccounts/apis/databases `
-ApiVersion "2015-04-08" -ResourceGroupName "RG-CosmosDB" -Name "dvzcos/sql/TimeTracker" `
| Select *

Get-AzResource -ResourceType Microsoft.DocumentDB/databaseAccounts/apis/databases/containers `
-ApiVersion "2015-04-08" -ResourceGroupName "RG-CosmosDB" -Name "dvzcos/sql/TimeTracker"

Get-AzResource -ResourceType Microsoft.DocumentDB/databaseAccounts/apis/databases/containers `
-ApiVersion "2015-04-08" -ResourceGroupName "RG-CosmosDB" `
-Name "dvzcos/sql/TimeTracker/TimeSlots" | Select *

# Work with the Az.CosmosDB module present

Get-AzCosmosDBAccount -ResourceGroupName RG-CosmosDB

Get-AzCosmosDBAccount -ResourceGroupName RG-CosmosDB -Name dvzcos

Get-AzCosmosDBAccountKey -ResourceGroupName RG-CosmosDB -Name dvzcos -Type "Keys"

Get-AzCosmosDBAccountKey -ResourceGroupName RG-CosmosDB -Name dvzcos -Type "ConnectionStrings"

Get-AzCosmosDBSqlDatabase -ResourceGroupName RG-CosmosDB -AccountName dvzcos

New-AzCosmosDBSqlDatabase -ResourceGroupName RG-CosmosDB -AccountName dvzcos -Name PSDB -Throughput 400

New-AzCosmosDBSqlContainer -ResourceGroupName RG-CosmosDB -AccountName dvzcos -DatabaseName PSDB `
 -Name Cities -PartitionKeyKind Hash -PartitionKeyPath "/cityname" -Throughput 400

 Get-AzCosmosDBSqlContainer -ResourceGroupName RG-CosmosDB -AccountName dvzcos -DatabaseName PSDB

#
# Part 3: Azure Stream Analytics
#  

# No commands here