#!/bin/bash
apt-get install -y apache2 php

echo "Hello from <b><?php echo gethostname(); ?></b>" | tee /var/www/html/index.php

systemctl restart apache2